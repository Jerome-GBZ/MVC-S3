<?php
  header("Location: Controler/index.ctrl.php");
?>
